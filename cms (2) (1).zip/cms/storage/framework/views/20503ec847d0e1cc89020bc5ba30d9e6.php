<!DOCTYPE html>
<html>
<head>
    <title>CMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

</head>
<body>

<div class="container">

    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <span class="navbar-text float-left">Lovely Professional University</span>
            <span class="navbar-text float-right">
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-warning" type="submit">Logout</button>
                </form>
            </span>
        </div>
    </nav>
    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html>
<?php /**PATH D:\laravel_projects\cms\cms\resources\views/students/layout.blade.php ENDPATH**/ ?>